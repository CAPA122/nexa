#!/bin/bash

while true
do
./wildrig-multi --algo megabtx --url stratum+tcp://megabtx.mine.zpool.ca:3558 --user sY7v3ieNguMPRd8XkzGdUtASDZFrCvdAmn --pass c=BTX,zap=BTX
sleep 5
done
