#!/bin/bash

while true
do
./wildrig-multi --algo shandwich256 --url stratum+tcp://stratum-eu.rplant.xyz:7091 --user PoolDonate --pass x
sleep 5
done
