#!/bin/bash

while true
do
./wildrig-multi --algo heavyhash --url stratum+tcp://pmpmining.com:3072 --user bc1qmukhr7sscdhy3kq3kyqae5k6grx0p4d9nlreet --pass x
sleep 5
done
