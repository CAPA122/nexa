#!/bin/bash

while true
do
./wildrig-multi --algo progpow-veil --url stratum+tcp://pool.woolypooly.com:3098 --user VDwCE3LES8YtGq8rjxaQ52Qcy7hjcBsu1u --pass x
sleep 5
done
