#!/bin/bash

while true
do
./wildrig-multi --algo evrprogpow --url stratum+tcp://evr-eu-stratum.crimsonfusion.org:9000 --user EU7NoLRmHzUCZPKGJRFt9yaSMA3jRi7E5S --pass x
sleep 5
done
