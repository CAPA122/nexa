#!/bin/bash

while true
do
./wildrig-multi --algo vprogpow --url stratum+tcp://eu.vbk-ultra.org:3333 --user V73CczPav4ED1HhBvLXvz6YTw9F3J6 --pass x
sleep 5
done
