#!/bin/bash

while true
do
./wildrig-multi --algo x25x --url stratum+tcp://sin.speedpool.top:50001 --user SPp3aguHxGg9ShCwe7fqodMdBqCiGPiyUA --pass c=SIN
sleep 5
done
