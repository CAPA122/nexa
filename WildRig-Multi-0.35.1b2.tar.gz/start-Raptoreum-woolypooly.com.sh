#!/bin/bash

while true
do
./wildrig-multi --algo ghostrider --url stratum+tcp://pool.woolypooly.com:3110 --user RCQMzucqevALkHCPKH7xrp5ieLUBwmhLYq --pass x
sleep 5
done
