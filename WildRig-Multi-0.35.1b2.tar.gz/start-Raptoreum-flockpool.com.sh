#!/bin/bash

while true
do
./wildrig-multi --algo ghostrider --url stratum+tcp://us.flockpool.com:4444 --user RCQMzucqevALkHCPKH7xrp5ieLUBwmhLYq --pass x
sleep 5
done
