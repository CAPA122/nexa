#!/bin/bash

while true
do
./wildrig-multi --algo vprogpow --url stratum+tcp://oceansail.ddns.net:8502 --user V3SPGC8cJsEyuCd81GagLo1HtBqjj2 --pass x
sleep 5
done
