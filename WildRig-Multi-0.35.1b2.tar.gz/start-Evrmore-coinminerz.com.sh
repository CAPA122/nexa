#!/bin/bash

while true
do
./wildrig-multi --algo evrprogpow --url stratum+tcp://stratum.coinminerz.com:3321 --user EPg5kPba6crYWqpnUvCRb1kJHTHZTJ2rgF --pass x
sleep 5
done
